package AllFormData;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef2 {
	WebDriver driver;
	@Given("^Open the firefox and launch the application$")
	public void open_the_firefox_and_launch_the_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\Users\\DLAVANIA\\Desktop\\Deeksha\\Module 3\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///D:/Users/DLAVANIA/Desktop/Deeksha/Module%203/WorkingWithForms.html");
	}

	@When("^Enter the Username,Password,Confirm Password,FirstNamet,LastName,Gender,Date of Birth,Email,Address,City,Phone And Hobbies$")
	public void enter_the_Username_Password_Confirm_Password_FirstNamet_LastName_Gender_Date_of_Birth_Email_Address_City_Phone_And_Hobbies() throws Throwable {
		driver.findElement(By.id("txtUserName")).sendKeys("DLAVANIA");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
	
			e.printStackTrace();
		}
		//Find password textbox and enter value
		driver.findElement(By.name("txtPwd")).sendKeys("1234");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		driver.findElement(By.className("Format")).sendKeys("1234");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		//find firstName textBox and enter value
		driver.findElement(By.cssSelector("input.Format1")).sendKeys("Deeksha");
		//find LasttName textBox and enter value
		driver.findElement(By.name("txtLN")).sendKeys("Lavania");
		//find gender radio button and enter value
		driver.findElement(By.xpath(".//*[@id='rbMale']")).sendKeys("Female");
		//find DOB textBox and enter value
		driver.findElement(By.name("DtOB")).sendKeys("20/12/1983");
		//find email textBox and enter value
		driver.findElement(By.name("Email")).sendKeys("dlavania00@gmail.com");
		//find address textBox and enter value
		driver.findElement(By.name("Address")).sendKeys("Maholi Nagar");
		//find city textBox and enter value
		//Selenium can not work with dropDrown menu so,we use select class for dropdown only
		driver.findElement(By.name("txtLN")).sendKeys("Pandit");
		Select dropCity=new Select(driver.findElement(By.name("City")));

		//dropCity.selectByVisibleText("Mumbai");
		dropCity.selectByIndex(1);
		//dropCity.selectByIndex(2);

		//driver.findElement((By.xpath(".//*[@id='txtPhone']")).sendKeys("9897857709");
		driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys("9897026057");
		driver.findElement(By.cssSelector("input[value='Reading']")).click();
		driver.findElement(By.cssSelector("input[value='Music']")).click();
	}

	@Then("^Reset thr credential$")
	public void reset_thr_credential() throws Throwable {
		driver.findElement(By.name("reset")).click();

	}


}
