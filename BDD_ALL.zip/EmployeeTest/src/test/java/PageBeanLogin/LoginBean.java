package PageBeanLogin;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginBean {
	WebDriver driver;
	
	@FindBy(id="employeeID")
	@CacheLookup
	WebElement pfnum;
	

	@FindBy(id="name")
	@CacheLookup
	WebElement pfname;


	@FindBy(id="city")
	@CacheLookup
	WebElement pfcity;

	@FindBy(id="state")
	@CacheLookup
	WebElement pfstate;
	

	@FindBy(xpath=".//*[@id='state']")
	@CacheLookup
	WebElement pfsubmit;

	public LoginBean(WebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getPfnum() {
		return pfnum;
	}

	public void setPfnum(String snum) {
	 pfnum.sendKeys(snum);
	}

	public WebElement getPfname() {
		return pfname;
	}

	public void setPfname(String sname) {
		pfname.sendKeys(sname);
	}

	public WebElement getPfcity() {
		return pfcity;
	}

	public void setPfcity(String scity) {
		pfcity.sendKeys(scity);
	}

	public WebElement getPfstate() {
		return pfstate;
	}

	public void setPfstate(String sstate) {
		pfstate.sendKeys(sstate);
	}

	public WebElement getPfsubmit() {
		return pfsubmit;
	}

	public void setPfsubmit() {
		pfsubmit.click();
	}
	
	

}
