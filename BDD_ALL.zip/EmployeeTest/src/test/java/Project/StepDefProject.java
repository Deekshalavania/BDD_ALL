package Project;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefProject {
	@Given("^user is on Project Page$")
	public void user_is_on_Project_Page() throws Throwable {
	 
	}

	@Then("^check the title$")
	public void check_the_title() throws Throwable {
	  
	}

	@When("^User enter all valid data$")
	public void user_enter_all_valid_data() throws Throwable {
	  
	}

	@Then("^navigate to registered Page$")
	public void navigate_to_registered_Page() throws Throwable {
	   
	}

	@When("^User leaves employeeName blank$")
	public void user_leaves_employeeName_blank() throws Throwable {

	}

	@Then("^display nameAlert msg$")
	public void display_nameAlert_msg() throws Throwable {
	
	}



}
