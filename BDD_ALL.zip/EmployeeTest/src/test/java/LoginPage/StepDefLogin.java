package LoginPage;



import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import PageBeanLogin.LoginBean;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefLogin {
WebDriver driver;
LoginBean log;

@Given("^user is on Login Page$")
public void user_is_on_Login_Page() throws Throwable {
	System.setProperty("webdriver.chrome.driver","D:\\Users\\DLAVANIA\\Desktop\\Deeksha\\Module 3\\chromeexe-master\\chromedriver_win32\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	log = new LoginBean(driver);
	driver.get("file:///D:/Users/DLAVANIA/Downloads/TeamProject-master/login1.html");
}

@Then("^check the title$")
public void check_the_title() throws Throwable {
	String title=driver.getTitle();
	if(title.contentEquals("Login Page")) System.out.println("***************TITLE MATCHED*************");
	else System.out.println("*****************TITLE DO NOT MATCHED*********************");
}

@When("^User enter all valid data$")
public void user_enter_all_valid_data() throws Throwable {
	log.setPfnum("21"); Thread.sleep(1000);
	log.setPfname("Sita"); Thread.sleep(1000);
	   log.setPfcity("Pune"); Thread.sleep(1000);
	   log.setPfstate("Maharashtra"); Thread.sleep(1000);
	   log.setPfsubmit();
}

@Then("^navigate to Project Page$")
public void navigate_to_Project_Page() throws Throwable {

	driver.navigate().to("file:///D:/Users/DLAVANIA/Downloads/TeamProject-master/project.html");
	driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	Thread.sleep(1000);
	driver.close();
}

@When("^User leaves employeeNo blank$")
public void user_leaves_employeeNo_blank() throws Throwable {
	log.setPfnum(""); Thread.sleep(1000);
	log.setPfname("Sita"); Thread.sleep(1000);
	   log.setPfcity("Pune"); Thread.sleep(1000);
	   log.setPfstate("Maharashtra"); Thread.sleep(1000);
	   log.setPfsubmit();
}

@Then("^display Alert msg$")
public void display_Alert_msg() throws Throwable {
	String alertMessage = driver.switchTo().alert().getText();
	Thread.sleep(1000);
	driver.switchTo().alert().accept();
    System.out.println("******" + alertMessage);
    driver.close();
	 

}

@When("^User leaves employeeName blank$")
public void user_leaves_employeeName_blank() throws Throwable {
	log.setPfnum("21"); Thread.sleep(1000);
	log.setPfname(""); Thread.sleep(1000);
	   log.setPfcity("Pune"); Thread.sleep(1000);
	   log.setPfstate("Maharashtra"); Thread.sleep(1000);
	   log.setPfsubmit();
}

@When("^User leaves city blank$")
public void user_leaves_city_blank() throws Throwable {
	log.setPfnum("21"); Thread.sleep(1000);
	log.setPfname("Sita"); Thread.sleep(1000);
	   log.setPfcity(""); Thread.sleep(1000);
	   log.setPfstate("Maharashtra"); Thread.sleep(1000);
	   log.setPfsubmit();
}

@When("^User leaves state blank$")
public void user_leaves_state_blank() throws Throwable {
	log.setPfnum("21"); Thread.sleep(1000);
	log.setPfname("Sita"); Thread.sleep(1000);
	   log.setPfcity("Pune"); Thread.sleep(1000);
	   log.setPfstate(""); Thread.sleep(1000);
	   log.setPfsubmit();
}
}
